from functions import generate_keypair, encrypt, decrypt, sign_message, verify_signature

p = 17
q = 13
public_key, private_key = generate_keypair(p, q)
plaintext = "My name is Bakhtiyar"
signature = sign_message(private_key, plaintext)
ciphertext = encrypt(public_key, plaintext)
decrypted_message = decrypt(private_key, ciphertext)
is_signature_valid = verify_signature(public_key, decrypted_message, signature)

print(f"\nPlaintext: {plaintext}")
print(f"Ciphertext: {ciphertext}")
print(f"Decrypted message: {decrypted_message}")
print(f"\nOriginal Digital Signature: {signature}")
print(f"Is Signature Valid: {is_signature_valid}")
